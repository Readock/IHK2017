var searchData=
[
  ['verarbeitung',['Verarbeitung',['../namespace_verarbeitung.html',1,'']]]
];
