var searchData=
[
  ['bedarf',['Bedarf',['../class_verarbeitung_1_1_bedarf.html',1,'Verarbeitung']]]
];
