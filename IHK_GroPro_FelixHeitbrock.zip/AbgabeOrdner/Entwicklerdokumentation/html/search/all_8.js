var searchData=
[
  ['lesen',['Lesen',['../class_eingabe_ausgabe_1_1_datei_einlesen.html#a5b319d99e4591de389ece62faf108580',1,'EingabeAusgabe.DateiEinlesen.Lesen()'],['../interface_eingabe_ausgabe_1_1_i_leser.html#a28a1fc6d88cffa848f205eda83967bc8',1,'EingabeAusgabe.ILeser.Lesen()']]]
];
