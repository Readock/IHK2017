var searchData=
[
  ['dateieinlesen_2ecs',['DateiEinlesen.cs',['../_datei_einlesen_8cs.html',1,'']]],
  ['dateischreiben_2ecs',['DateiSchreiben.cs',['../_datei_schreiben_8cs.html',1,'']]]
];
