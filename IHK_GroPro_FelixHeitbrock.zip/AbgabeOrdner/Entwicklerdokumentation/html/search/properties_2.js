var searchData=
[
  ['daten',['Daten',['../class_verarbeitung_1_1_bedarf.html#a5f687e90254bc2035d30978d801d9ebc',1,'Verarbeitung::Bedarf']]]
];
