var searchData=
[
  ['vorfaktoren',['Vorfaktoren',['../class_verarbeitung_1_1_polynom.html#a03a25d4ac655a9cbd25e44db54ba8b18',1,'Verarbeitung::Polynom']]]
];
