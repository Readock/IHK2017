var searchData=
[
  ['ihkexception',['IHKException',['../class_fehlerbehandung_1_1_i_h_k_exception.html',1,'Fehlerbehandung']]],
  ['ileser',['ILeser',['../interface_eingabe_ausgabe_1_1_i_leser.html',1,'EingabeAusgabe']]],
  ['ischreiber',['ISchreiber',['../interface_eingabe_ausgabe_1_1_i_schreiber.html',1,'EingabeAusgabe']]]
];
