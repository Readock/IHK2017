var searchData=
[
  ['inputdata',['InputData',['../class_eingabe_ausgabe_1_1_ausgabe_daten.html#ace3844204df18c2ea2ba5fd406a65e8b',1,'EingabeAusgabe::AusgabeDaten']]],
  ['isnachfrage',['IsNachfrage',['../class_verarbeitung_1_1_aenderung.html#a9602e529b4a363f899d14c730f3d33e0',1,'Verarbeitung::Aenderung']]]
];
