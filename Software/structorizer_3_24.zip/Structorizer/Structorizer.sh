java -jar Structorizer.app/Contents/Resources/Java/Structorizer.jar $1
